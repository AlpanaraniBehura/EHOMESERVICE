"""OnlineHome URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Public.views import (
    Home, 
    About, 
    Contact, 
    Login, 
    Logout, 
    Signup,
    ManagerSignup,
    AdminSignup,
    SendEmailForForgotPassword,
    ForgotPassword
)
from Admin.views import (
    My_Profile, 
    ChangePassword, 
    Update_User_Profile, 
    AddServiceRequest, 
    UserServiceRequest,
    EditServiceRequest,
    AllServiceRequest,
    AllUser,
    Profile,
    DeleteUser,
    AssignTeam,
    AllServiceApproveRequest,
    TrackRequest,
    CompleteRequest,
    ApproveRequest,
    RejectRequest,
    AllServiceAssignedRequest,
    AllCompletedServiceRequest,
    DeleteService,
    Dashboard,
    ViewFeedback,
    AddFeedback,
    AddServiceProvider,
    EditServiceProvider,
    AllServiceProvider,
    DeleteServiceProvider,
    AddProvidedService,
    DeleteProvidedService,
    EditProvidedService,
    ProvidedServices,
    AllServices,
    SelectProvider,
    AddUserServiceRequest
)

from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path('admin/', admin.site.urls),

    # Public URLs
    path('', Home, name='home'),
    path('about/', About, name='about'),
    path('contact/', Contact, name='contact'),
    path('login/', Login, name='login'),
    path('logout/', Logout, name='logout'),
    path('signup/', Signup, name='signup'),
    path('manager-signup/', ManagerSignup, name='manager-signup'),
    path('admin-signup/', AdminSignup, name='admin-signup'),
    path('email-forgotpassword/', SendEmailForForgotPassword, name='email-forgotpassword'),
    path('forgot-password/', ForgotPassword, name='forgot-password'),
    path('change-password/', ChangePassword, name='change-password'),


    # Admin URLs
    path('profile/', My_Profile, name='profile'),
    
    path('add-service-provider/', AddServiceProvider, name='add-service-provider'),
    path('select-provider/', SelectProvider ,name='select-provider'),
    
    path('dashboard/', Dashboard, name='dashboard'),
    path('all-user/', AllUser, name='all-user'),
    path('user-detail/<int:id>/', Profile, name='user-detail'),
    path('delete-user/<int:id>/', DeleteUser, name='delete-user'),
    path('assign-team/<int:id>/', AssignTeam, name='assign-team'),
    path('add-service-request/<int:id>/', AddServiceRequest, name='add-service-request'),
    path('edit-service-request/<int:id>/', EditServiceRequest, name='edit-service-request'),
    path('user-service-request/', UserServiceRequest, name='user-service-request'),
    path('add-user-service-request/', AddUserServiceRequest, name='add-user-service-request'),
    path('track-request/<int:id>/', TrackRequest, name='track-request'),
    path('complete-request/<int:id>/', CompleteRequest, name='complete-request'),
    path('approve-request/<int:id>/', ApproveRequest, name='approve-request'),
    path('reject-request/<int:id>/', RejectRequest, name='reject-request'),
    path('all-service-request/', AllServiceRequest, name='all-service-request'),
    
    
    path('all-service-provider/', AllServiceProvider, name="all-service-provider"),
    path('edit-service-provider/<int:id>/', EditServiceProvider, name='edit-service-provider'),
    path('delete-provider/<int:id>/', DeleteServiceProvider, name="delete-provider"),

    path('add-provided-service/', AddProvidedService, name='add-provided-service'),
    path('delete-provided-service/<int:id>/', DeleteProvidedService, name='delete-provided-service'),
    path('edit-provided-service/<int:id>/', EditProvidedService, name='edit-provided-service'),

    path('all-services/', AllServices, name='all-services'),
    path('provided-service/<int:id>/', ProvidedServices, name='provided-service'),
    path('view-feedback/', ViewFeedback, name='view-feedback'),
    path('add-feedback/<int:id>/', AddFeedback, name='add-feedback'),

    path('all-completed-service-request/', AllCompletedServiceRequest, name='all-completed-service-request'),
    path('all-approve-request/', AllServiceApproveRequest, name='all-approve-request'),
    path('delete-service/<int:id>/', DeleteService, name='delete-service'),
    path('all-assigned-request/', AllServiceAssignedRequest, name='all-assigned-request'),
    path('update-profile/<int:id>/', Update_User_Profile, name='update-profile'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


handler404 = 'Admin.views.error_404'