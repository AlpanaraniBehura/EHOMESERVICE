from django.contrib import admin
from Public.models import UserProfile
# Register your models here.

admin.site.register(UserProfile)