from django.shortcuts import render, redirect
from django.contrib.auth import authenticate,login,logout

from django.contrib.auth.models import User
from Public.models import UserProfile
from .models import Service, Track, ServiceProvider, ProvideService

from django.core.mail import send_mail
from django.conf import settings

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Create your views here.
def My_Profile(request):
    return render(request, 'userprofile.html')

def Profile(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    user = UserProfile.objects.get(id=id)
    return render(request, 'user-details.html', {'userdetail':user})


def AllUser(request):
    if not request.user.is_authenticated:
        return redirect('login')
    user = UserProfile.objects.exclude(user=request.user)
    return render(request, 'view-user.html', {'users':user})


def DeleteUser(request,id):
    if not request.user.is_authenticated:
        return redirect('login')
    user = User.objects.get(id=id)
    user.delete()
    return redirect('all-user')



def SelectProvider(request):
    if not request.user.is_authenticated:
        return redirect('login')
    p = ServiceProvider.objects.filter(is_verified=True)
    if request.method == "POST":
        service_provider = request.POST.get('service-provider')
        return redirect('add-service-request', id=int(service_provider))
    return render(request, 'select-provider.html', {"provider":p})


def Update_User_Profile(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    
    details = UserProfile.objects.get(id=id)

    if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        contact = request.POST.get('contact')
        address = request.POST.get('address')
        email = request.POST.get('email')
        dob = request.POST.get('dob')
        pic = request.FILES.get('pic')
        
        if len(contact)<10 or len(contact)>10:
            msg = 'Phone Number Should be equal to 10 digit'
            return render(request, 'userupdateprofile.html', {'detail':details, 'msg':msg})         
        
        if dob:
            details.dob = dob
        details.contact_No = contact
        details.address = address
        details.profilePicture = pic
        details.user.first_name = first_name
        details.user.last_name = last_name
        details.user.email = email
        details.user.save()
        details.save()
        u = request.user
        p = UserProfile.objects.get(user=u)
        if p.userType == "Admin":
            return redirect('all-user')
        details = UserProfile.objects.get(id=id)
    return render(request, 'userupdateprofile.html', {'detail':details})


def AssignTeam(request,id):
    if not request.user.is_authenticated:
        return redirect('login')
    s = Service.objects.get(id=id)
    if request.method == "POST":
        service_boy_phone = request.POST.get('service_boy_phone')
        service_boy_name = request.POST.get('service_boy_name')
        price = request.POST.get('price')
        Track.objects.create(service=s, service_boy_phone=service_boy_phone, service_boy_name=service_boy_name)
        s.status = "Assigned Team"
        s.price=int(price)
        s.save()
        return redirect('all-approve-request')
    return render(request, 'assign-team.html', {'service':s})

def ChangePassword(request):
    if not request.user.is_authenticated:
        return redirect('login')
    msg = ''
    if request.method == "POST":
        username = request.user.username
        oldpass = request.POST.get('oldpass')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password1!=password2:
            msg='New and Confirm Password should be same.'
            return render(request,'changepass.html', {'msg':msg})
              
        user = User.objects.get(username=username)
        newpass = user.check_password(oldpass)
        
        if newpass:
            user.set_password(password1)
            user.save()
            data=authenticate(username=username,password=password1)
            if data !=None:
                login(request,data)
                return redirect('profile')
        msg='Old Password should be same.'
        return render(request,'changepass.html', {'msg':msg})
        
    return render(request,'changepass.html', {'msg':msg})


def AddServiceProvider(request):
    if not request.user.is_authenticated:
        return redirect('login')
    msg = ''
    if request.method == "POST":
        name = request.POST.get('name')
        owner_phone_no = request.POST.get('owner_phone_no')
        
        if len(owner_phone_no) != 10:
            msg = 'Phone Number Should be equal to 10 digit'
            return render(request, 'add-service-provider.html', {'msg':msg})
        
        up = UserProfile.objects.get(user=request.user)
        ServiceProvider.objects.create(user=up, name=name, owner_phone_no=owner_phone_no)
        return redirect('all-service-request')
    return render(request, 'add-service-provider.html', {'msg':msg})


def AllServiceProvider(request):
    if not request.user.is_authenticated:
        return redirect('login')
    provider = ServiceProvider.objects.all()

    page = request.GET.get('page', 1)
    paginator = Paginator(provider, 10)
    try:
        p = paginator.page(page)
    except PageNotAnInteger:
        p = paginator.page(1)
    except EmptyPage:
        p = paginator.page(paginator.num_pages)

    return render(request, 'view-service-provider.html', {'provider': p})


def EditServiceProvider(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    msg = ''
    sp = ServiceProvider.objects.get(id=id)
    if request.method == "POST":
        name = request.POST.get('name')
        owner_phone_no = request.POST.get('owner_phone_no')
        is_verified = request.POST.get('is_verified')
        
        if len(owner_phone_no) != 10:
            msg = 'Phone Number Should be equal to 10 digit'
            return render(request, 'edit-service-provider.html', {"sp": sp, 'msg':msg})
        
        up = UserProfile.objects.get(user=request.user)
        sp.name=name
        sp.owner_phone_no=owner_phone_no
        sp.is_verified=is_verified
        sp.save()
        return redirect('all-service-provider')
    return render(request, 'edit-service-provider.html', {"sp": sp, 'msg':msg})

def DeleteServiceProvider(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    p = ServiceProvider.objects.get(id=id)
    p.delete()
    return redirect('all-service-provider')


def AddServiceRequest(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    s = ServiceProvider.objects.get(id=id)
    p = ProvideService.objects.filter(provider=s)
    return render(request, 'service-rqst.html', {'provider': p})


def AddUserServiceRequest(request):
    if request.method == "POST":
        user = UserProfile.objects.get(user=request.user)
        type_of_service = request.POST.get('type_of_service')
        date = request.POST.get('Date')
        contact = request.POST.get('contact')
        address = request.POST.get('address')

        if len(contact) != 10:
            msg = 'Phone Number Should be equal to 10 digit'
            return render(request, 'service-rqst.html', {"provider":p, 'msg':msg})

        provider_service = ProvideService.objects.get(id=int(type_of_service))
        Service.objects.create(userprofile=user, type_of_service=provider_service, date=date, phone_no=int(contact), address=address)
        return redirect('user-service-request')
    


def UserServiceRequest(request):
    if not request.user.is_authenticated:
        return redirect('login')
    userp = UserProfile.objects.get(user=request.user)
    user_request = Service.objects.filter(userprofile=userp)
    
    return render(request, 'view-rqst.html', {'userrequest':user_request})


def EditServiceRequest(request,id):
    if not request.user.is_authenticated:
        return redirect('login')
    s = Service.objects.get(id=id)
    if request.method == "POST":
        type_of_service = request.POST.get('type_of_service')
        date = request.POST.get('Date')
        contact = request.POST.get('contact')
        address = request.POST.get('address')

        s.type_of_service = type_of_service
        s.date = date
        s.contact = contact
        s.address = address
        s.save()
        s = Service.objects.get(id=id)
    return render(request, 'edit-service.html', {'servicedetail':s})


def AllServiceRequest(request):
    if not request.user.is_authenticated:
        return redirect('login')
    user = UserProfile.objects.get(user=request.user)
    if not user.userType == "Admin":
        return redirect('profile')
    
    s = Service.objects.filter(status="Pending").order_by('-id')
    return render(request, 'view-rqst.html', {'userrequest':s})


def AllCompletedServiceRequest(request):
    if not request.user.is_authenticated:
        return redirect('login')
    user = UserProfile.objects.get(user=request.user)
    if not user.userType == "Admin":
        return redirect('profile')
    
    s = Service.objects.filter(status="Completed").order_by('-id')
    return render(request, 'view-rqst.html', {'userrequest':s})


def AllServiceApproveRequest(request):
    if not request.user.is_authenticated:
        return redirect('login')
    
    s = Service.objects.filter(status="Approved").order_by('-id')
    return render(request, 'view-rqst.html', {'userrequest':s})


def AllServiceAssignedRequest(request):
    if not request.user.is_authenticated:
        return redirect('login')
    
    s = Service.objects.filter(status="Assigned Team").order_by('-id')
    return render(request, 'view-rqst.html', {'userrequest':s})


def TrackRequest(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    s = Service.objects.get(id=id)
    t = Track.objects.get(service=s)
    return render(request, 'trackservice.html', {'track':t})


def CompleteRequest(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    s = Service.objects.get(id=id)
    s.status = "Completed"
    s.save()
    body = f'Hello {s.userprofile.user.first_name}, \n\n Your Service has been Completed. \n\n Thank You '
    subject = 'E-Home Services'
    from_email = settings.EMAIL_HOST_USER
    to_email = [s.userprofile.user.email]
    send_mail(subject, body, from_email, to_email, fail_silently=True)
    return redirect('all-approve-request')


def ApproveRequest(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    s = Service.objects.get(id=id)
    s.status = "Approved"
    s.save()
    body = f'Hello {s.userprofile.user.first_name}, \n\n Your Service has been Approved by Admin. \n\n Thank You '
    subject = 'E-Home Services'
    from_email = settings.EMAIL_HOST_USER
    to_email = [s.userprofile.user.email]
    send_mail(subject, body, from_email, to_email, fail_silently=True)
    return redirect('all-service-request')


def RejectRequest(request,id):
    if not request.user.is_authenticated:
        return redirect('login')
    s = Service.objects.get(id=id)
    s.status = "Rejected"
    s.save()
    body = f'Hello {s.userprofile.user.first_name}, \n\n Your Service has been Rejected by Admin. \n\n Thank You '
    subject = 'E-Home Services'
    from_email = settings.EMAIL_HOST_USER
    to_email = [s.userprofile.user.email]
    send_mail(subject, body, from_email, to_email, fail_silently=True)
    return redirect('all-service-request')


def DeleteService(request,id):
    if not request.user.is_authenticated:
        return redirect('login')
    user = Service.objects.get(id=id)
    user.delete()
    return redirect('all-completed-service-request')


def Dashboard(request):
    if not request.user.is_authenticated:
        return redirect('login')
    total_verified_provider = ServiceProvider.objects.filter(is_verified=True)
    total_unverified_provider = ServiceProvider.objects.filter(is_verified=False)
    pending_services = Service.objects.filter(status="Pending")
    completed_services = Service.objects.filter(status="Completed")
    rejected_services = Service.objects.filter(status="Rejected")
    total_assigned_service = Service.objects.filter(status="Assigned Team")

    u = UserProfile.objects.get(user=request.user)
    user_total_service_applied = Service.objects.filter(userprofile=u)
    user_total_pending_service = Service.objects.filter(userprofile=u, status="Pending")
    user_total_completed_service = Service.objects.filter(userprofile=u, status="Completed")
    

    Dict = {
        "total_verified_provider": total_verified_provider.count(),
        "total_unverified_provider": total_unverified_provider.count(),
        "pending_services": pending_services.count(),
        "completed_services": completed_services.count(),
        "rejected_services": rejected_services.count(),
        "total_assigned_service": total_assigned_service.count(),

        "user_total_service_applied": user_total_service_applied.count(),
        "user_total_pending_service": user_total_pending_service.count(),
        "user_total_completed_service": user_total_completed_service.count()
    }
    return render(request, 'dashboard.html', Dict)


def ViewFeedback(request):
    if not request.user.is_authenticated:
        return redirect('login')
    return render(request, 'feedback.html')


def AddFeedback(request,id):
    if not request.user.is_authenticated:
        return redirect('login')
    s = Service.objects.get(id=id)
    if request.method == "POST":
        user_feedback = request.POST.get('feedback')
        s.user_feedback=user_feedback
        s.save()
        
        body = f'Hello {s.type_of_service.provider.user.user.first_name}, \n\n Your Service {s.type_of_service.name}  has a new feedback added by {request.user.first_name} {request.user.last_name}. \n\n Thank You '
        subject = 'E-Home Services'
        from_email = settings.EMAIL_HOST_USER
        to_email = [s.type_of_service.provider.user.user.email]
        send_mail(subject, body, from_email, to_email, fail_silently=True)
        return redirect('user-service-request')
    return render(request, 'feedback.html', {'s':s})


def AddProvidedService(request):
    if not request.user.is_authenticated:
        return redirect('login')
    ps = ServiceProvider.objects.all()
    if request.method == "POST":
        provider = request.POST.get('provider')
        name = request.POST.get('name')
        
        provider = ServiceProvider.objects.get(id=int(provider))
        ProvideService.objects.create(provider=provider, name=name)
        return redirect('all-service-provider')
    return render(request, 'add-provided-service.html', {"ps":ps})



def AllServices(request):
    if not request.user.is_authenticated:
        return redirect('login')
    p = ServiceProvider.objects.all()
    s = ProvideService.objects.all().order_by('-id')

    page = request.GET.get('page', 1)
    paginator = Paginator(s, 10)
    try:
        service = paginator.page(page)
    except PageNotAnInteger:
        service = paginator.page(1)
    except EmptyPage:
        service = paginator.page(paginator.num_pages)
    return render(request, 'service-details.html', {'provider': p, 'page': service})


def ProvidedServices(request, id):
    p = ServiceProvider.objects.all()
    s = ProvideService.objects.filter(provider=ServiceProvider.objects.get(id=id))

    page = request.GET.get('page', 1)
    paginator = Paginator(s, 10)
    try:
        service = paginator.page(page)
    except PageNotAnInteger:
        service = paginator.page(1)
    except EmptyPage:
        service = paginator.page(paginator.num_pages)
    return render(request, 'service-details.html', {'provider': p, "page": service})


def EditProvidedService(request, id):
    if not request.user.is_authenticated:
        return redirect('login')
    
    s = ProvideService.objects.get(id=id)
    p = ServiceProvider.objects.exclude(name=s.provider.name)
    
    if request.method == "POST":
        provider = request.POST.get('provider')
        name = request.POST.get('name')

        ps = ServiceProvider.objects.get(id=int(provider))
        s.provider=ps
        s.name=name
        s.save()
        return redirect('all-services')
    return render(request, 'edit-provided-service.html', {'provider': p, "serviceinfo": s})


def DeleteProvidedService(request, id):
    s = ProvideService.objects.get(id=id)
    s.delete()
    return redirect('all-services')


def error_404(request, exception):
    return render(request,'404.html')