from django.db import models
from Public.models import UserProfile

import random
# Create your models here.


class ServiceProvider(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    owner_phone_no = models.PositiveIntegerField()
    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class ProvideService(models.Model):
    provider = models.ForeignKey(ServiceProvider, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Service(models.Model):
    STATUS = (
        ('Pending','Pending'),
        ('Approved', 'Approved'),
        ('Completed', 'Completed'),
        ('Assigned Team', 'Assigned Team'),
        ('Rejected', 'Rejected')
    )
    userprofile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    status = models.CharField(max_length=50, choices=STATUS, default='Pending')
    type_of_service = models.ForeignKey(ProvideService, on_delete=models.CASCADE, null=True)
    date = models.DateField()
    phone_no = models.PositiveIntegerField()
    price = models.PositiveIntegerField(null=True)
    address = models.TextField()
    user_feedback = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.type_of_service} of {self.userprofile.user.first_name}"

class Track(models.Model):
    def TrackId():
        return str(random.randint(1000000, 9999999))
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name="track_service")
    service_boy_name = models.CharField(max_length=255)
    service_boy_phone = models.IntegerField()
    track_id = models.IntegerField(default=TrackId)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Track of id {self.track_id}"